package com.example.UserList.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import com.example.UserList.entity.User;
import com.example.UserList.serviceImpl.UserServiceImpl;


@Controller
public class UserController {

  @Autowired
  private UserServiceImpl userService;



  @GetMapping("/getUsers")
  public ResponseEntity<List<User>> getAllUsers() {

    List<User> list = userService.getAllUsers();
    return new ResponseEntity<List<User>>(list, HttpStatus.OK);
  }

  // for json but it gets automatically converted
  // @GetMapping(value = "/getDummyUser/{city}", produces = "application/json")
  @GetMapping(value = "/getDummyUser/{city}")
  public ResponseEntity<User> getDummyUser(@PathVariable String city) {
    User user = userService.getDummyUser(city);
    return new ResponseEntity<User>(user, HttpStatus.OK);
  }

  @PostMapping("/saveUser")
  public String saveUser(@ModelAttribute("user") User user) {
    userService.saveUser(user);
    return "redirect:/";
  }

  @PutMapping("/updateUser")
  public User updateUser(@ModelAttribute("user") User user) {
    user = userService.updateUser(user);
    return user;
  }


  @GetMapping("/")
  public String viewHomePage(Model model) {
    model.addAttribute("listOfUsers", userService.getAllUsers());
    return "index";

  }

  @GetMapping("/newUserForm")
  public String showUserForm(Model model) {
    User user = new User();
    model.addAttribute("user", user);
    return "newUser";
  }

  // // to add user we need save also
  // @PostMapping("/saveUser")
  // public String saveUser(@ModelAttribute("user") User user) {
  // userService.saveUser(user);
  // return "redirect:/";
  //
  // }

  // @GetMapping("/getUser/{id}")
  // public User getUserById(@PathVariable Integer id) {
  // User user = userService.findByUserId(id);
  // return user;
  // }

}
