package com.example.UserList.repository;

import java.util.List;
import com.example.UserList.entity.User;

public interface UserRepository {
  User findUserByCity(String city);

  User findUserByName(String name);

  List<User> findAll();

  User save(User user);

  User update(User user);

  // List<User> paging(int start, int maxResults);

}
