package com.example.UserList.serviceImpl;

import java.util.List;
import com.example.UserList.entity.User;


public interface UserService {
  List<User> getAllUsers();

  User getDummyUser(String state);

  void saveUser(User user);

  User updateUser(User user);

}
