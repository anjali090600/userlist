package com.example.UserList.serviceImpl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.UserList.entity.User;
import com.example.UserList.repository.UserRepoImpl;
import jakarta.transaction.Transactional;

@Service
public class UserServiceImpl implements UserService {

  @Autowired
  private UserRepoImpl userRepo;



  public List<User> getAllUsers() {
    return userRepo.findAll();
  }

  public User getDummyUser(String state) {
    // return userRepo.findUserByState(state);
    return userRepo.findUserByCity(state);
  }


  @Transactional
  public void saveUser(User user) {
    userRepo.save(user);
  }

  public User updateUser(User user) {
    return userRepo.update(user);
  }



  /*
   * // @Autowired //private UserRepository userRepo;
   * 
   * // @Autowired // private UserDAO userDAO;
   * 
   * // @Override // public List<User> getAllUsers() { // // return this.userRepo.findAll(); // }
   * 
   * // @Override // public User saveUser(User user) { // return this.userRepo.save(user); // // }
   * // // public User findByUserId(Integer id) { // TODO: Search the user. // Optional<User> myUser
   * = userDAO.findByUserId(id); // return myUser.get(); // } // // @Override public User
   * saveUser(User user) { // Optional<String> myUsername = userDAO.getUserByName(user.getName());
   * // // if (myUsername.isPresent()) { // String name = myUsername.get(); // if
   * (!StringUtils.isEmpty(name)) // return null; // Apache StringUtils.isEmpty returns a boolean
   * true if the string is either // // null or has length is zero // // Java String.isEmpty returns
   * a boolean true if the string’s length is zero. If // // the string has null it throws
   * NullPointerException // } // // return this.userRepo.save(user); // // }
   * 
   */

}
