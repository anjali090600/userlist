package com.example.UserList.repository;

import java.util.List;
import java.util.Objects;
import org.springframework.stereotype.Repository;
import com.example.UserList.entity.User;
import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import jakarta.persistence.TypedQuery;

@Repository
public class UserRepoImpl implements UserRepository {

  @PersistenceContext
  private EntityManager entityManager;

  public User findUserByCity(String city) {
    String sql = "FROM User where city = :city";
    Query nativeQuery = entityManager.createNativeQuery(sql, User.class);
    nativeQuery.setParameter("city", city);
    return (User) nativeQuery.getSingleResult();

  }

  // if you know the result of type
  public User findUserByName(String name) {
    String sql = "FROM User where name = :name";
    TypedQuery<User> typedQuery = entityManager.createQuery(sql, User.class);

    typedQuery.setParameter("name", name);
    User user = null;
    try {
      user = typedQuery.getSingleResult();
    } catch (NoResultException e) {
      // do nothing.
      // Thrown by the persistence provider when Query.getSingleResult()
      // or TypedQuery.getSingleResult()is executed on a query and there is no result to return
    }
    return user;
  }

  @SuppressWarnings("unchecked")
  public List<User> findAll() {
    String sql = "FROM User";
    Query usersQuery = entityManager.createQuery(sql, List.class);
    return usersQuery.getResultList();
  }

  public User save(User user) {
    if (Objects.isNull(findUserByName(user.getName()))) {
      entityManager.persist(user);

      return user;
    }
    return null;
  }



  public User update(User user) {
    if (Objects.isNull(user.getId())) {
      entityManager.persist(user); // save the user if id is null.
    } else {
      // to update the user.
      user = entityManager.merge(user);
    }
    return user;
  }

  // @SuppressWarnings("unchecked")
  // public List<User> paging(int start, int maxResults) {
  // String sql = "FROM User";
  // Query pagingQuery = entityManager.createQuery(sql, List.class);
  // pagingQuery.setFirstResult(start);
  // pagingQuery.setMaxResults(maxResults);
  // return pagingQuery.getResultList();
  //
  // }


}
